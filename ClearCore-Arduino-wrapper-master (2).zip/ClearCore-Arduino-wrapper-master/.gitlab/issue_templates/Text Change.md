**Location**

(Where is the location of the intended change?)


**What is the error?**

(Specifically state what the problem with the text is whether it's a typo, a grammatical error, a formatting error, or just unclear text descriptions)


**Steps to reproduce?**

(If there was any setup to illicit the typo/formatting error/grammatical error, list them)


**What is the suggested correction?**

(Specifically state your suggestion to correct the spelling or make the text more clear)


/label ~Text Change 