# Examples for Teknic ClearCore

When you have the Teknic ClearCore device selected in the Arduino IDE, these examples will appear in the File/Examples menu item under the "Examples for Teknic ClearCore" heading.